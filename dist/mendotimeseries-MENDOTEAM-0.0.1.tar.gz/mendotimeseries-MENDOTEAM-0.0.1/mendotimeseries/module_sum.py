def sum(a, b):
    '''
    Returns the sum between "a" and "b"
    '''
    return a + b
