# MendoTimeSeries

- Predicts all you want
